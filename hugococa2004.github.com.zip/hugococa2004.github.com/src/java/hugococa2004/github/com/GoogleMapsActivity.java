/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.location.LocationListener
 *  android.location.LocationManager
 *  android.os.Bundle
 *  android.util.DisplayMetrics
 *  android.util.SparseBooleanArray
 *  android.util.TypedValue
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.webkit.WebSettings
 *  android.webkit.WebView
 *  android.webkit.WebViewClient
 *  android.widget.Button
 *  android.widget.LinearLayout
 *  android.widget.ListView
 *  android.widget.Toast
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.core.app.ActivityCompat
 *  androidx.core.content.ContextCompat
 *  java.lang.CharSequence
 *  java.lang.Deprecated
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Random
 *  java.util.Timer
 *  java.util.TimerTask
 */
package hugococa2004.github.com;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import hugococa2004.github.com.R;
import hugococa2004.github.com.SketchwareUtil;
import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class GoogleMapsActivity
extends AppCompatActivity {
    private LocationManager GoogleMapsLoc;
    private LocationListener _GoogleMapsLoc_location_listener;
    private Timer _timer = new Timer();
    private Button button1;
    private LinearLayout linear1;
    private TimerTask time;
    private AlertDialog.Builder tuto_maps;
    private Intent tutomaps = new Intent();
    private WebView webview1;

    private void initialize(Bundle bundle) {
        this.linear1 = (LinearLayout)this.findViewById(R.id.linear1);
        this.webview1 = (WebView)this.findViewById(R.id.webview1);
        this.webview1.getSettings().setJavaScriptEnabled(true);
        this.webview1.getSettings().setSupportZoom(true);
        this.button1 = (Button)this.findViewById(R.id.button1);
        this.tuto_maps = new AlertDialog.Builder((Context)this);
        this.GoogleMapsLoc = (LocationManager)this.getSystemService("location");
        this.webview1.setWebViewClient(new WebViewClient(){

            public void onPageFinished(WebView webView, String string2) {
                super.onPageFinished(webView, string2);
            }

            public void onPageStarted(WebView webView, String string2, Bitmap bitmap) {
                super.onPageStarted(webView, string2, bitmap);
            }
        });
        this.button1.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                GoogleMapsActivity.this.finish();
            }
        });
    }

    private void initializeLogic() {
        this.webview1.loadUrl("https://www.google.fr/maps/");
        SketchwareUtil.showMessage(this.getApplicationContext(), "Pour revenir \u00e0 la page d'accueil, veuillez appuyer sur \"retour\".");
        this.time = new TimerTask(){

            public void run() {
                GoogleMapsActivity.this.runOnUiThread(new Runnable(){

                    public void run() {
                        SketchwareUtil.showMessage(3.this.GoogleMapsActivity.this.getApplicationContext(), "Pour revenir \u00e0 la page d'accueil, veuillez appuyer sur \"retour\".");
                    }
                });
            }

        };
        this._timer.schedule(this.time, 2000L);
    }

    @Deprecated
    public ArrayList<Double> getCheckedItemPositionsToArray(ListView listView) {
        ArrayList arrayList = new ArrayList();
        SparseBooleanArray sparseBooleanArray = listView.getCheckedItemPositions();
        int n = 0;
        while (n < sparseBooleanArray.size()) {
            if (sparseBooleanArray.valueAt(n)) {
                arrayList.add((Object)sparseBooleanArray.keyAt(n));
            }
            ++n;
        }
        return arrayList;
    }

    @Deprecated
    public float getDip(int n) {
        return TypedValue.applyDimension((int)1, (float)n, (DisplayMetrics)this.getResources().getDisplayMetrics());
    }

    @Deprecated
    public int getDisplayHeightPixels() {
        return this.getResources().getDisplayMetrics().heightPixels;
    }

    @Deprecated
    public int getDisplayWidthPixels() {
        return this.getResources().getDisplayMetrics().widthPixels;
    }

    @Deprecated
    public int getLocationX(View view) {
        int[] arrn = new int[2];
        view.getLocationInWindow(arrn);
        return arrn[0];
    }

    @Deprecated
    public int getLocationY(View view) {
        int[] arrn = new int[2];
        view.getLocationInWindow(arrn);
        return arrn[1];
    }

    @Deprecated
    public int getRandom(int n, int n2) {
        return n + new Random().nextInt(1 + (n2 - n));
    }

    protected void onActivityResult(int n, int n2, Intent intent) {
        super.onActivityResult(n, n2, intent);
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.google_maps);
        this.initialize(bundle);
        if (ContextCompat.checkSelfPermission((Context)this, (String)"android.permission.ACCESS_FINE_LOCATION") == -1) {
            ActivityCompat.requestPermissions((Activity)this, (String[])new String[]{"android.permission.ACCESS_FINE_LOCATION"}, (int)1000);
            return;
        }
        this.initializeLogic();
    }

    public void onRequestPermissionsResult(int n, String[] arrstring, int[] arrn) {
        super.onRequestPermissionsResult(n, arrstring, arrn);
        if (n == 1000) {
            this.initializeLogic();
        }
    }

    @Deprecated
    public void showMessage(String string2) {
        Toast.makeText((Context)this.getApplicationContext(), (CharSequence)string2, (int)0).show();
    }

}

