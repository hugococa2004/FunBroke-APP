/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.net.Uri
 *  android.os.Bundle
 *  android.os.Vibrator
 *  android.util.DisplayMetrics
 *  android.util.SparseBooleanArray
 *  android.util.TypedValue
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.webkit.WebSettings
 *  android.webkit.WebView
 *  android.webkit.WebViewClient
 *  android.widget.Button
 *  android.widget.CompoundButton
 *  android.widget.CompoundButton$OnCheckedChangeListener
 *  android.widget.LinearLayout
 *  android.widget.ListView
 *  android.widget.ProgressBar
 *  android.widget.ScrollView
 *  android.widget.Switch
 *  android.widget.TextView
 *  android.widget.Toast
 *  androidx.appcompat.app.ActionBar
 *  androidx.appcompat.app.ActionBarDrawerToggle
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.appcompat.widget.Toolbar
 *  androidx.drawerlayout.widget.DrawerLayout
 *  androidx.drawerlayout.widget.DrawerLayout$DrawerListener
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Random
 *  java.util.Timer
 *  java.util.TimerTask
 */
package hugococa2004.github.com;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Vibrator;
import android.util.DisplayMetrics;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import hugococa2004.github.com.GoogleMapsActivity;
import hugococa2004.github.com.R;
import hugococa2004.github.com.SketchwareUtil;
import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity
extends AppCompatActivity {
    private DrawerLayout _drawer;
    private Button _drawer_button1;
    private Button _drawer_button4;
    private Button _drawer_button5;
    private LinearLayout _drawer_linear1;
    private Timer _timer = new Timer();
    private Toolbar _toolbar;
    private Intent a = new Intent();
    private Vibrator brrrrrrr;
    private Button button2;
    private Button button5555;
    private Button button6;
    private Intent i = new Intent();
    private LinearLayout linear3;
    private LinearLayout linear5;
    private ProgressBar progressbar1;
    private AlertDialog.Builder secret;
    private Switch switch1;
    private TextView textview23;
    private TextView textview33;
    private TextView textview34;
    private TextView textview35;
    private TextView textview36;
    private TimerTask timu;
    private Intent transition = new Intent();
    private AlertDialog.Builder tuto_discord;
    private AlertDialog.Builder vernote;
    private Vibrator vib1;
    private ScrollView vscroll1;
    private WebView webview1;
    private AlertDialog.Builder y;

    private void initialize(Bundle bundle) {
        this._toolbar = (Toolbar)this.findViewById(R.id._toolbar);
        this.setSupportActionBar(this._toolbar);
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.getSupportActionBar().setHomeButtonEnabled(true);
        this._toolbar.setNavigationOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                MainActivity.this.onBackPressed();
            }
        });
        this._drawer = (DrawerLayout)this.findViewById(R.id._drawer);
        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle((Activity)this, this._drawer, this._toolbar, R.string.app_name, R.string.app_name);
        this._drawer.addDrawerListener((DrawerLayout.DrawerListener)actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
        LinearLayout linearLayout = (LinearLayout)this.findViewById(R.id._nav_view);
        this.linear5 = (LinearLayout)this.findViewById(R.id.linear5);
        this.vscroll1 = (ScrollView)this.findViewById(R.id.vscroll1);
        this.linear3 = (LinearLayout)this.findViewById(R.id.linear3);
        this.textview23 = (TextView)this.findViewById(R.id.textview23);
        this.textview33 = (TextView)this.findViewById(R.id.textview33);
        this.button2 = (Button)this.findViewById(R.id.button2);
        this.button5555 = (Button)this.findViewById(R.id.button5555);
        this.switch1 = (Switch)this.findViewById(R.id.switch1);
        this.button6 = (Button)this.findViewById(R.id.button6);
        this.textview34 = (TextView)this.findViewById(R.id.textview34);
        this.textview35 = (TextView)this.findViewById(R.id.textview35);
        this.progressbar1 = (ProgressBar)this.findViewById(R.id.progressbar1);
        this.textview36 = (TextView)this.findViewById(R.id.textview36);
        this.webview1 = (WebView)this.findViewById(R.id.webview1);
        this.webview1.getSettings().setJavaScriptEnabled(true);
        this.webview1.getSettings().setSupportZoom(true);
        this._drawer_linear1 = (LinearLayout)linearLayout.findViewById(R.id.linear1);
        this._drawer_button1 = (Button)linearLayout.findViewById(R.id.button1);
        this._drawer_button4 = (Button)linearLayout.findViewById(R.id.button4);
        this._drawer_button5 = (Button)linearLayout.findViewById(R.id.button5);
        this.vernote = new AlertDialog.Builder((Context)this);
        this.tuto_discord = new AlertDialog.Builder((Context)this);
        this.vib1 = (Vibrator)this.getSystemService("vibrator");
        this.secret = new AlertDialog.Builder((Context)this);
        this.y = new AlertDialog.Builder((Context)this);
        this.brrrrrrr = (Vibrator)this.getSystemService("vibrator");
        this.linear5.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
            }
        });
        this.linear3.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
            }
        });
        this.textview23.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
            }
        });
        this.textview33.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
            }
        });
        this.button2.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                MainActivity.this.tuto_discord.setTitle((CharSequence)"Notre serveur Discord");
                MainActivity.this.tuto_discord.setMessage((CharSequence)"Pour rejoindre notre serveur Discord il faut coller le lien qui est dans le presse-papiers dans l'application Discord ou dans un navigateur internet.");
                MainActivity.this.tuto_discord.setPositiveButton((CharSequence)"ok, je fait \u00e7a !", new DialogInterface.OnClickListener(){

                    public void onClick(DialogInterface dialogInterface, int n) {
                        6.this.MainActivity.this.y.setTitle((CharSequence)"chois de l'application");
                        6.this.MainActivity.this.y.setMessage((CharSequence)"D'accord, vous voulez ouvrir quelle application ?");
                        6.this.MainActivity.this.y.setPositiveButton((CharSequence)"navigateur internet", new DialogInterface.OnClickListener(){

                            public void onClick(DialogInterface dialogInterface, int n) {
                                1.this.6.this.MainActivity.this.i.setAction("android.intent.action.VIEW");
                                1.this.6.this.MainActivity.this.i.setData(Uri.parse((String)"https://discord.gg/GKCkXkS"));
                                1.this.6.this.MainActivity.this.startActivity(1.this.6.this.MainActivity.this.i);
                            }
                        });
                        6.this.MainActivity.this.y.setNegativeButton((CharSequence)"Discord", new DialogInterface.OnClickListener(){

                            public void onClick(DialogInterface dialogInterface, int n) {
                                1.this.6.this.MainActivity.this.i.setAction("android.intent.action.VIEW");
                                1.this.6.this.MainActivity.this.i.setData(Uri.parse((String)"android-app://com.discord"));
                                1.this.6.this.MainActivity.this.startActivity(1.this.6.this.MainActivity.this.i);
                            }
                        });
                        6.this.MainActivity.this.y.create().show();
                    }

                });
                MainActivity.this.tuto_discord.setNeutralButton((CharSequence)"ok, je vais faire \u00e7a une prochaine fois", new DialogInterface.OnClickListener(){

                    public void onClick(DialogInterface dialogInterface, int n) {
                    }
                });
                MainActivity.this.tuto_discord.setNegativeButton((CharSequence)"non, merci !", new DialogInterface.OnClickListener(){

                    public void onClick(DialogInterface dialogInterface, int n) {
                    }
                });
                MainActivity.this.tuto_discord.create().show();
            }

        });
        this.button5555.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                MainActivity.this.vernote.setTitle((CharSequence)"\ud83d\udcdc Nouveaut\u00e9s ! \ud83d\udcdc");
                MainActivity.this.vernote.setMessage((CharSequence)"1.0: release officiel ! \ud83c\udf8a");
                MainActivity.this.vernote.setPositiveButton((CharSequence)"ok", new DialogInterface.OnClickListener(){

                    public void onClick(DialogInterface dialogInterface, int n) {
                    }
                });
                MainActivity.this.vernote.create().show();
            }

        });
        this.switch1.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
            }
        });
        this.switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

            public void onCheckedChanged(CompoundButton compoundButton, boolean bl) {
                if (MainActivity.this.switch1.isChecked()) {
                    MainActivity.this.switch1.setText((CharSequence)"Th\u00e8me sombre");
                    MainActivity.this.switch1.setTextColor(-14575885);
                    MainActivity.this.linear5.setBackgroundColor(-1);
                    MainActivity.this.linear3.setBackgroundColor(-1);
                    MainActivity.this.vscroll1.setBackgroundColor(-1);
                    MainActivity.this.switch1.setBackgroundColor(0);
                    return;
                }
                MainActivity.this.switch1.setText((CharSequence)"Th\u00e8me clair");
                MainActivity.this.switch1.setTextColor(-43230);
                MainActivity.this.linear5.setBackgroundColor(-16777216);
                MainActivity.this.linear3.setBackgroundColor(-16777216);
                MainActivity.this.vscroll1.setBackgroundColor(-16777216);
                MainActivity.this.switch1.setBackgroundColor(0);
                MainActivity.this.switch1.setBackgroundColor(0);
            }
        });
        this.button6.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                MainActivity.this.brrrrrrr.vibrate(2004L);
                MainActivity.this.a.setAction("android.intent.action.VIEW");
                MainActivity.this.a.setData(Uri.parse((String)"https://www.youtube.com/watch?v=dQw4w9WgXcQ"));
                MainActivity.this.startActivity(MainActivity.this.a);
            }
        });
        this.webview1.setWebViewClient(new WebViewClient(){

            public void onPageFinished(WebView webView, String string2) {
                MainActivity.this.webview1.setVisibility(0);
                MainActivity.this.progressbar1.setVisibility(4);
                super.onPageFinished(webView, string2);
            }

            public void onPageStarted(WebView webView, String string2, Bitmap bitmap) {
                MainActivity.this.progressbar1.setVisibility(0);
                MainActivity.this.webview1.setVisibility(4);
                super.onPageStarted(webView, string2, bitmap);
            }
        });
        this._drawer_linear1.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
            }
        });
        this._drawer_button1.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                MainActivity.this.transition.setClass(MainActivity.this.getApplicationContext(), GoogleMapsActivity.class);
                MainActivity.this.startActivity(MainActivity.this.transition);
            }
        });
        this._drawer_button4.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                MainActivity.this.secret.setTitle((CharSequence)"En d\u00e9veloppement..");
                MainActivity.this.secret.setMessage((CharSequence)"Le th\u00e8me claire pour le drawer n'est pas disponible pour l'instant.");
                MainActivity.this.secret.setPositiveButton((CharSequence)"ok", new DialogInterface.OnClickListener(){

                    public void onClick(DialogInterface dialogInterface, int n) {
                        14.this.MainActivity.this.button6.setTranslationX(25.0f + 14.this.MainActivity.this.button6.getTranslationX());
                        14.this.MainActivity.this._drawer.closeDrawer(8388611);
                    }
                });
                MainActivity.this.secret.create().show();
            }

        });
        this._drawer_button5.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                MainActivity.this.finish();
            }
        });
    }

    private void initializeLogic() {
        this.webview1.loadUrl("https://hugococa2004.github.io/fun-broke.html");
    }

    @Deprecated
    public ArrayList<Double> getCheckedItemPositionsToArray(ListView listView) {
        ArrayList arrayList = new ArrayList();
        SparseBooleanArray sparseBooleanArray = listView.getCheckedItemPositions();
        int n = 0;
        while (n < sparseBooleanArray.size()) {
            if (sparseBooleanArray.valueAt(n)) {
                arrayList.add((Object)sparseBooleanArray.keyAt(n));
            }
            ++n;
        }
        return arrayList;
    }

    @Deprecated
    public float getDip(int n) {
        return TypedValue.applyDimension((int)1, (float)n, (DisplayMetrics)this.getResources().getDisplayMetrics());
    }

    @Deprecated
    public int getDisplayHeightPixels() {
        return this.getResources().getDisplayMetrics().heightPixels;
    }

    @Deprecated
    public int getDisplayWidthPixels() {
        return this.getResources().getDisplayMetrics().widthPixels;
    }

    @Deprecated
    public int getLocationX(View view) {
        int[] arrn = new int[2];
        view.getLocationInWindow(arrn);
        return arrn[0];
    }

    @Deprecated
    public int getLocationY(View view) {
        int[] arrn = new int[2];
        view.getLocationInWindow(arrn);
        return arrn[1];
    }

    @Deprecated
    public int getRandom(int n, int n2) {
        return n + new Random().nextInt(1 + (n2 - n));
    }

    protected void onActivityResult(int n, int n2, Intent intent) {
        super.onActivityResult(n, n2, intent);
    }

    public void onBackPressed() {
        this.webview1.goBack();
        SketchwareUtil.showMessage(this.getApplicationContext(), "Pour quitter l'application, veuillez appuyer sur le bouton \"Quitter\" qui se trouve dans le drawer.");
        this.timu = new TimerTask(){

            public void run() {
                MainActivity.this.runOnUiThread(new Runnable(){

                    public void run() {
                        SketchwareUtil.showMessage(16.this.MainActivity.this.getApplicationContext(), "Pour quitter l'application, veuillez appuyer sur le bouton \"Quitter\" qui se trouve dans le drawer.");
                    }
                });
            }

        };
        this._timer.schedule(this.timu, 3000L);
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.main);
        this.initialize(bundle);
        this.initializeLogic();
    }

    public void onDestroy() {
        super.onDestroy();
    }

    public void onPause() {
        super.onPause();
    }

    protected void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
    }

    public void onResume() {
        super.onResume();
    }

    public void onStart() {
        super.onStart();
    }

    public void onStop() {
        super.onStop();
    }

    @Deprecated
    public void showMessage(String string2) {
        Toast.makeText((Context)this.getApplicationContext(), (CharSequence)string2, (int)0).show();
    }

}

